import type {
  CrisisEvent,
  CrisisDetail,
  SafeRoute,
  CitizenReport,
  PublicAlert,
} from '../types';

const BACKEND_URL =
  process.env.EXPO_PUBLIC_BACKEND_URL || 'http://localhost:8000';

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BACKEND_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
  });
  if (!res.ok) throw new Error(`GET ${path} → ${res.status}`);
  return res.json() as Promise<T>;
}

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${BACKEND_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`POST ${path} → ${res.status}`);
  return res.json() as Promise<T>;
}

export async function fetchActiveCrises(): Promise<CrisisEvent[]> {
  try {
    const data = await get<CrisisEvent[]>('/api/v2/crisis/active');
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function fetchCrisisDetail(id: string): Promise<CrisisDetail | null> {
  try {
    return await get<CrisisDetail>(`/api/v2/crisis/${id}`);
  } catch {
    return null;
  }
}

export async function fetchSafeRoutes(crisisId: string): Promise<SafeRoute[]> {
  try {
    const data = await get<{ routes: SafeRoute[] }>(
      `/api/v2/mobile/routes/${crisisId}`
    );
    return data.routes ?? [];
  } catch {
    return [];
  }
}

export async function fetchNearbyAlerts(
  lat: number,
  lng: number,
  radiusKm = 10
): Promise<PublicAlert[]> {
  try {
    const data = await get<PublicAlert[]>(
      `/api/v2/mobile/alerts?lat=${lat}&lng=${lng}&radius=${radiusKm}`
    );
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function fetchVoiceAlertUrl(crisisId: string): Promise<string | null> {
  try {
    const data = await get<{ url: string }>(`/api/v2/mobile/crisis/${crisisId}/audio`);
    return data.url ?? null;
  } catch {
    return null;
  }
}

export async function submitCitizenReport(
  report: CitizenReport
): Promise<{ report_id: string; status: string } | null> {
  try {
    return await post('/api/v2/reports', report);
  } catch {
    return null;
  }
}

export async function triggerDemo(): Promise<void> {
  await post('/api/v2/debug/inject-scenario', { scenario: 'g10_flood' });
}
